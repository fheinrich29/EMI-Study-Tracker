package com.example.masha.vorlesungen_uebungen;

/**
 * Created by Masha on 05.01.2018.
 */

public class Vorlesungen_data {
}
//Hier muss Information über Vorlesungen stehen - Nummer, Daten usw.
//Ich gebe hier jetzt nur Sample List als Beispiel.