package com.example.masha.vorlesungen_uebungen;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Masha on 05.01.2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    List<Lectures> lecturesList = new ArrayList<>();

    public MyAdapter(List<Lectures> lectures){
        lecturesList = lectures;
    }

    public void DataSetChanged(List<Lectures> lecturesList){
        this.lecturesList = lecturesList;
        notifyDataSetChanged();

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_vorlesung, parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.number.setText(lecturesList).get(position).getName();//?? nicht sicher

    }

    @Override
    public int getItemCount() {
        return lecturesList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView number;

        public MyViewHolder(View itemView){
            super(itemView);
            number = (TextView) itemView.findViewById(R.id.number);
        }
}

}

//Jetzt brauchen wir 2 Klassen mit Daten hier: für Number (Nummer der Vorlesung) und Date